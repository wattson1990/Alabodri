# 404: FOUND — Blue Field Guide

## Run locally
Open `ssa/SSA.html` in a modern browser. All original illustrations, GIFs, and the custom typeface are stored alongside the HTML. The redesign styles and interactions are separated into `ssa/custom.css` and `ssa/interactions.js`; the page needs no build step or external JavaScript dependencies.

## What changed
- Kept the original educational text, timeline entries, illustrations, animated GIFs, and typeface.
- Reworked the layout into a responsive midnight/ice-blue editorial interface with frosted panels, subtle grain, and a compact bento overview.
- Added a floating chapter image preview, contextual cursor, magnetic links, image tilt/highlight, scroll progress, reveal-on-scroll, a horizontal era selector, and a draggable note.
- Added reduced-motion and touch-device fallbacks.

## Pinterest design direction
The blue palette references Pinterest's 2026 **Cool Blue** palette (notably `#D7EFFF`) and pairs it with deeper navy and clear cyan accents. The interaction language is informed by exploratory Pinterest searches for these visual directions:

- Pinterest Palette 2026 — Cool Blue: https://newsroom.pinterest.com/en-gb/pdf/pinterest-palette-2026-pdf/?change_language=true&page=1
- Blue glassmorphism web design: https://www.pinterest.com/search/pins/?q=blue%20glassmorphism%20web%20design
- Blue editorial web design: https://www.pinterest.com/search/pins/?q=blue%20editorial%20web%20design
- Cursor hover interaction web design: https://www.pinterest.com/search/pins/?q=cursor%20hover%20interaction%20web%20design
- Blue parallax website design: https://www.pinterest.com/search/pins/?q=blue%20parallax%20website%20design

The references are used for visual direction only; no Pinterest images or third-party assets are embedded in the site.
